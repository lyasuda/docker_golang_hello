package br.com.bytebank.banco;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

public class JavaMoney {

    public static void main (String [] args){

        List<String> list = Arrays.asList("node", "java", "python", "ruby");

        list.forEach(new Consumer<String>() {       // anonymous class
            @Override
            public void accept(String str) {
                System.out.println(str);
            }
        });

        list.forEach(str -> System.out.println(str));
    }
}
