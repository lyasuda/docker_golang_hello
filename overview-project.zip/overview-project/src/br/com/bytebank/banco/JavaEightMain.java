package br.com.bytebank.banco;

import br.com.bytebank.banco.modelo.Cliente;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class JavaEightMain {

    public static void main (String [] args){

        List<String> listaFrameworks = Arrays.asList("node", "java", "python", "ruby");

        listaFrameworks.forEach(f -> {
                System.out.println(f);
                                    });

        //Concatena nome e profissão e separa por virgula, sabendo o final da iteração
        List<Cliente> listaClientes = Arrays.asList(
                new Cliente("Leandro", "Analista"),
                new Cliente("Yasuda", "Gerente"));

        String clientes = listaClientes.stream().map(c -> c.getNome() + " - " + c.getProfissao()).collect(Collectors.joining(", "));

        System.out.println(clientes);


    }
}
