package br.com.bytebank.banco;

import br.com.bytebank.banco.modelo.Cliente;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class JavaFunctionMain {

    public static void main(String[] args) {

        List<String> lines = Arrays.asList("spring", "node", "java");

        //stream.filter() to filter a List, and collect() to convert a stream into a List
        List<String> result = lines.stream().filter(linha -> !"java".equals(linha)).collect(Collectors.toList());

        result.forEach(System.out::println);


        List<Cliente> clientes = Arrays.asList(
                new Cliente("Leandro", "Analista"),
                new Cliente("João", "Gerente"),
                new Cliente("Pedro", "QA"));

        //stream.filter() to filter a List, and .findAny().orElse (null) to return an object conditional.
        //// Convert to stream
        Cliente result1 = clientes.stream()
                //// we want "Leandro" only
                .filter(c -> "Leandro".equals(c.getNome()))
                //// If 'findAny' then return found
                .findAny()
                //// If not found, return null
                .orElse(null);

        System.out.println("Cliente { Nome: " + result1.getNome() + ", " + "Profissão: " + result1.getProfissao());

    }
}
