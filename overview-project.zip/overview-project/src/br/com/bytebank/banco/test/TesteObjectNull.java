package br.com.bytebank.banco.test;

public class TesteObjectNull {

    public static void main (String[] args){


    }
}
