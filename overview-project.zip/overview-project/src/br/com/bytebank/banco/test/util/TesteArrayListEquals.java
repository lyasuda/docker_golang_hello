package br.com.bytebank.banco.test.util;

import br.com.bytebank.banco.modelo.Conta;
import br.com.bytebank.banco.modelo.ContaCorrente;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TesteArrayListEquals {

    public static void main(String[] args){

        //generics
        ArrayList<Conta> lista = new ArrayList<Conta>();

        List<Integer> novaLista =  Arrays.asList(1,1,1);

        Conta cc1 = new ContaCorrente(22, 21);
        Conta cc2 = new ContaCorrente(22, 22);

        lista.add(cc1);

        boolean existe = lista.contains(cc2); //novo
        System.out.println("Já existe? " + existe);

        boolean igual = cc1.ehIgual(cc2);
        System.out.println(igual);


        for(Conta conta : lista) {
            System.out.println(conta);
        }
    }

}